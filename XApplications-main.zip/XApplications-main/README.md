# XApplications
A user-friendly web portal designed for managing applications in FiveM servers. Streamline your server's recruitment process with an intuitive interface, customizable forms, and efficient applicant tracking.

### Please consider giving a star to the project!

## Features
- Admin Dashboard
- Reviewer Dashboard
- Application Page
- Discord Synced

## Setup
Since the project is built using NextJS it's recommended to host using Vercel, a tutorial on how to do that can be found at [hosting-your-first-website-on-vercel-a-step-by-step-guide](https://medium.com/@hikmohadetunji/hosting-your-first-website-on-vercel-a-step-by-step-guide-95061f1ca687). If you need further help join my discord server linked below.

# Discord
https://discord.gg/Q6ynnA8z
